package edu.iesmre.up4;

public class TaquillaConcert {
    private int placesDisponibles;

    public TaquillaConcert(int placesInicials) {
        if (placesInicials < 0) {
            throw new IllegalArgumentException("Les places inicials no poden ser negatives");
        }
        placesDisponibles = placesInicials;
    }

    public int consultarPlaces() {
        return placesDisponibles;
    }

    public int vendreEntrades(int quantitat, boolean entradaReduida) {
        if (quantitat <= 0) {
            throw new IllegalArgumentException("Cal comprar almenys una entrada");
        }
        if (quantitat > placesDisponibles) {
            throw new IllegalStateException("No queden prou places");
        }

        int preuUnitari;
        if (entradaReduida) {
            preuUnitari = 8;
        } else {
            preuUnitari = 12;
        }

        placesDisponibles = placesDisponibles - quantitat;
        return quantitat * preuUnitari;
    }
}
