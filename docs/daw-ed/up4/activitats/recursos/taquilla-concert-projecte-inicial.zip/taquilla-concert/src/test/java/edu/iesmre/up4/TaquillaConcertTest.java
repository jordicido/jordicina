package edu.iesmre.up4;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TaquillaConcertTest {
    // Escriu ací els teus casos de prova.
    // Recorda: 3 de retorn, 3 d'estat i 3 d'excepcions.
    // Cada prova ha de crear una TaquillaConcert nova.
}
